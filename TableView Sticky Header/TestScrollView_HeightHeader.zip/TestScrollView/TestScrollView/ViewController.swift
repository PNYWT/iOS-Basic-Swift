//
//  ViewController.swift
//  TestScrollView
//
//  Created by Dev on 17/6/2567 BE.
//

import UIKit
import SnapKit

class ViewController: UIViewController {
    
    private lazy var tableView: UITableView! = {
        let tableView = UITableView()
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.register(UITableViewCell.self,forCellReuseIdentifier: "cell")
        tableView.dataSource = self
        tableView.delegate = self
        tableView.backgroundColor = .blue
        return tableView
    }()
    private lazy var headerView: CustomHeaderView! = {
        let view = CustomHeaderView(frame: .zero, title: "ABC")
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    private var headerHeightConstraint: Constraint!
    private var maxHeightHeaderView: CGFloat = 200
    private var minimumHeightHeaderView: CGFloat = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setUpHeader()
        setUpTableView()
    }
    
    private func setUpHeader() {
        view.addSubview(headerView)
        
        headerView.snp.makeConstraints { make in
            make.top.leading.trailing.equalTo(view.safeAreaLayoutGuide)
            headerHeightConstraint = make.height.equalTo(maxHeightHeaderView).constraint
            headerHeightConstraint?.isActive = true
        }
    }
    
    private func setUpTableView() {
        view.addSubview(tableView)
        
        tableView.snp.makeConstraints { make in
            make.top.equalTo(headerView.snp.bottom)
            make.bottom.leading.trailing.equalTo(view.safeAreaLayoutGuide)
        }
    }


    private func animateHeader() {
        headerView.snp.updateConstraints { make in
            make.height.equalTo(maxHeightHeaderView)
        }
        UIView.animate(withDuration: 0.4, delay: 0.0, usingSpringWithDamping: 0.7, initialSpringVelocity: 0.5, options: .curveEaseInOut, animations: {
            self.view.layoutIfNeeded()
        }, completion: nil)
    }
}


extension ViewController: UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        guard let currentHeight = headerHeightConstraint?.layoutConstraints.first?.constant else {
            return
        }
        if scrollView.contentOffset.y < 0 {
            let newHeight = currentHeight + abs(scrollView.contentOffset.y)
            headerHeightConstraint?.update(offset: newHeight)
            headerView.incrementColorAlpha(offset: newHeight)
            headerView.incrementArticleAlpha(offset: newHeight)
        } else if scrollView.contentOffset.y > 0 && currentHeight >= minimumHeightHeaderView {
            let newHeight = currentHeight - (scrollView.contentOffset.y / 100)
            headerHeightConstraint?.update(offset: newHeight)
            headerView.decrementColorAlpha(offset: scrollView.contentOffset.y)
            headerView.decrementArticleAlpha(offset: newHeight)
            if newHeight < minimumHeightHeaderView {
                headerHeightConstraint?.update(offset: minimumHeightHeaderView)
            }
        }
    }
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        guard let currentHeight = headerHeightConstraint?.layoutConstraints.first?.constant else {
            return
        }
        if currentHeight > maxHeightHeaderView {
            animateHeader()
        }
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        guard let currentHeight = headerHeightConstraint?.layoutConstraints.first?.constant else {
            return
        }
        if currentHeight > maxHeightHeaderView {
            animateHeader()
        }
    }
}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 100
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell",   for: indexPath as IndexPath)
        cell.backgroundColor = .clear
        cell.textLabel?.text = "Article \(indexPath.row)"
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
    }
}

extension UIView {
    func roundCorners(corners: UIRectCorner, radius: CGFloat) {
        let path = UIBezierPath(roundedRect: bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        let mask = CAShapeLayer()
        mask.path = path.cgPath
        layer.mask = mask
    }
}
