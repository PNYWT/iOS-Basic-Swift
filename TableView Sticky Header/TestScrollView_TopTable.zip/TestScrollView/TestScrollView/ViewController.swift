//
//  ViewController.swift
//  TestScrollView
//
//  Created by Dev on 17/6/2567 BE.
//

import UIKit
import SnapKit

class ViewController: UIViewController {
    
    private lazy var tableView: UITableView! = {
        let tableView = UITableView()
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.register(UITableViewCell.self,forCellReuseIdentifier: "cell")
        tableView.dataSource = self
        tableView.delegate = self
        tableView.backgroundColor = .blue
        return tableView
    }()
    private lazy var headerView: CustomHeaderView! = {
        let view = CustomHeaderView(frame: .zero, title: "ABC")
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    private var topTableConstraint: Constraint!
    private var maxSpaceTop: CGFloat = 200
    private var minimumSpaceTop: CGFloat {
        get {
            return view.safeAreaInsets.top
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setUpHeader()
        setUpTableView()
    }
    
    private func setUpHeader() {
        view.addSubview(headerView)
        
        headerView.snp.makeConstraints { make in
            make.top.leading.trailing.equalTo(view.safeAreaLayoutGuide)
            make.height.equalTo(maxSpaceTop)
//            headerHeightConstraint = make.height.equalTo(maxHeightHeaderView).constraint
//            headerHeightConstraint?.isActive = true
        }
    }
    
    private func setUpTableView() {
        view.addSubview(tableView)
        
        tableView.snp.makeConstraints { make in
            topTableConstraint = make.top.equalTo(view.snp.top).offset(maxSpaceTop).constraint
            make.bottom.leading.trailing.equalTo(view.safeAreaLayoutGuide)
        }
    }


    private func animateHeader() {
        headerView.snp.updateConstraints { make in
            make.height.equalTo(maxSpaceTop)
        }
        UIView.animate(withDuration: 1.0, delay: 0.0, usingSpringWithDamping: 0.7, initialSpringVelocity: 0.5, options: .curveEaseInOut, animations: {
            self.view.layoutIfNeeded()
        }, completion: nil)
    }
}


extension ViewController: UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        guard let currentTop = topTableConstraint?.layoutConstraints.first?.constant else {
            return
        }
        if scrollView.contentOffset.y < 0 {
            topTableConstraint?.update(offset: maxSpaceTop)
        } else if scrollView.contentOffset.y > 0 && currentTop >= minimumSpaceTop { // กำลังเลื่อนลงล่าง top ยังไม่ติดขอบ view top
            let newTop = currentTop - (scrollView.contentOffset.y / 100)
            topTableConstraint?.update(offset: newTop)
            if newTop < minimumSpaceTop { // เลื่อนลงล่าง top ติด view top
                topTableConstraint?.update(offset: minimumSpaceTop)
            }
        }
    }
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        guard let currentTop = topTableConstraint?.layoutConstraints.first?.constant else {
            return
        }
        if currentTop > maxSpaceTop {
            animateHeader()
        }
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        guard let currentTop = topTableConstraint?.layoutConstraints.first?.constant else {
            return
        }
        if currentTop > maxSpaceTop {
            animateHeader()
        }
    }
}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 100
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell",   for: indexPath as IndexPath)
        cell.backgroundColor = .clear
        cell.textLabel?.text = "Article \(indexPath.row)"
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
    }
}

extension UIView {
    func roundCorners(corners: UIRectCorner, radius: CGFloat) {
        let path = UIBezierPath(roundedRect: bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        let mask = CAShapeLayer()
        mask.path = path.cgPath
        layer.mask = mask
    }
}
